<?php

require __DIR__  . '/vendor/autoload.php';

$handle = fopen('php://input','r'); // Open file for reading only
$jSon = fgets($handle); // Reads the file and stores it in the variable as a jSon string
$data = json_decode($jSon, true); // Takes the jSon string and turns it in an associative array (the "true" parameter)

$paymentId = $data["paymentId"];
$purchaseAmount = $data["purchaseAmount"];
$purchaseCurrency = $data["purchaseCurrency"];

$credentials = new \PayPal\Auth\OAuthTokenCredential(
        	'YOUR SANDBOX ClientID',
        	'YOUR SANDBOX ClientSecret'
);
	
$apiContext = new \PayPal\Rest\ApiContext($credentials);

try 
{
    	$payment = \PayPal\Api\Payment::get($paymentId, $apiContext);
	$paymentState = $payment->state;
	$transaction = $payment->transactions[0];
	$amount = $transaction->amount;
	$currency = $amount->currency;
	$total = $amount->total;
	
	$continue = false;
	
	if (($purchaseAmount == $total) && ($purchaseCurrency == $currency))
	{
		$continue = true;
	}
	
	if ($continue == false)
	{
		$response = array('status' => 'Failure', 'message' => 'Amount or currency incorrect.');
		echo json_encode($response);
		exit(0);
	}

	if ($paymentState == "approved") 
	{
		$response = array('status' => 'Success', 'message' => 'Payment successfully completed!');
		echo json_encode($response);
	}
	else
	{
		$response = array('status' => 'Failure', 'message' => 'Payment not approved.');
		echo json_encode($response);
	}
} 
catch (Exception $ex) 
{
	$response = array('status' => 'Failure', 'message' => 'Failed getting payment object.');
	echo json_encode($response);
}

?>
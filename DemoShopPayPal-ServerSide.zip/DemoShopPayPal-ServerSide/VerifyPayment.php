<?php

require __DIR__  . '/vendor/autoload.php';

$handle = fopen('php://input','r'); // Open file for reading only
$jSon = fgets($handle); // Reads the file and stores it in the variable as a jSon string
$data = json_decode($jSon, true); // Takes the jSon string and turns it in an associative array (the "true" parameter)

// Data from client side:
$paymentId = $data["paymentId"];
$amountClient = $data["purchaseAmount"];
$currencyClient = $data["purchaseCurrency"];

$credentials = new \PayPal\Auth\OAuthTokenCredential(
        	'YOUR SANDBOX Client ID',
        	'YOUR SANDBOX Client Secret'
);
	
$apiContext = new \PayPal\Rest\ApiContext($credentials);

try 
{
    $payment = \PayPal\Api\Payment::get($paymentId, $apiContext);
	$paymentState = $payment->getState();
	$transactions = $payment->getTransactions();
	$transaction = $transactions[0];
	$total = $transaction->getAmount()->getTotal();
	$currency = $transaction->getAmount()->getCurrency();
	$relatedResources = $transaction->getRelatedResources();
	$saleState = $relatedResources[0]->getSale()->getState();
	
	if ($paymentState != "approved") 
	{
		$response = array('status' => 'Failure', 'message' => 'Payment not approved.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($amountClient != $total)
	{
		$response = array('status' => 'Failure', 'message' => 'Incorrect payment amount.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($currencyClient != $currency)
	{
		$response = array('status' => 'Failure', 'message' => 'Incorrect payment currency.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($saleState != "completed")
	{
		$response = array('status' => 'Failure', 'message' => 'Sale not completed.');
		echo json_encode($response);
		exit(0);
	}
	
	$response = array('status' => 'Success', 'message' => 'Payment successfully completed!');
	echo json_encode($response);
} 
catch (Exception $ex) 
{
	$response = array('status' => 'Failure', 'message' => 'Failed getting payment object.');
	echo json_encode($response);
}

?>